
package trabalho1_marcospietrucci;

/**
 * Classe que define os tiros
 * @author Marcos Pietrucci
 * @since Oct 2020
 */
public class Tiro extends Elemento {
    
    
    Tiro(int x, int y, char simbol, int vidas)
    {
        super(x,y,simbol,vidas);
    }
    
}
