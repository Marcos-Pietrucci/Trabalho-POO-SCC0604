package trabalho1_marcospietrucci;

/**
 * Classe que define as barreiras que defendem o canhão
 * @author Marcos Pietrucci
 * @since Oct 2020
 */
public class Barreira extends Elemento{
    
    Barreira(int x, int y, char simbol, int vidas)
    {
        super(x,y,simbol,vidas);
    }
}
